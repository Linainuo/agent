
class ReviewAgent:
    def run(self, code: str):
        print("[Review] 正在检查代码质量...")

        if "pass" in code:
            return "检测到代码未完整实现"

        return "代码检查通过"
