
class CodingAgent:
    def run(self, task: str):
        print(f"[Coding] 正在生成代码: {task}")

        fake_code = {
            "创建数据库模型": "class User(db.Model): pass",
            "生成后端接口": "@app.route('/login')",
            "生成前端页面": "<LoginPage />",
            "编写测试用例": "def test_login(): pass"
        }

        return fake_code.get(task, "")
