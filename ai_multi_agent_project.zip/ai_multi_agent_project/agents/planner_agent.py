
class PlannerAgent:
    def run(self, requirement: str):
        print("[Planner] 正在拆解任务...")

        return [
            "创建数据库模型",
            "生成后端接口",
            "生成前端页面",
            "编写测试用例"
        ]
