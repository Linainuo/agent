
class TestingAgent:
    def run(self, code: str):
        print("[Testing] 正在运行测试...")

        return len(code) >= 10
